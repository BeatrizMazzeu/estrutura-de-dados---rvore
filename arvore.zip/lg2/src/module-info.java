module lg2 {
}